/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090907, Chapter 4 Drills
 */

#include <iostream>

using namespace std;

int main (int argc, char * const argv[]) {
    // insert code here...
	
	double i,j;
	cout.setf(ios::fixed);
	while(true) {
		cin >> i >> j;
		if(!cin.good())
			break; // avoid printing the last stuff
					// in the event of bad input
		cout << "The smaller value is: " << ((i<j)?i:j) << endl;
		cout << "The larger value is:  " << ((i>j)?i:j) << endl;
		if(i-j<=1.0/10000000)
			cout << "The numbers are almost equal" << endl;
	}
	
	cout << "bye!" << endl;
	
    return 0;
}
