/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090907, Chapter 4 Drills
 */

#include <iostream>

using namespace std;

int main (int argc, char * const argv[]) {
    // insert code here...
	
	double large=0.00,small=0.00,i;
	bool start=true;
	cout.setf(ios::fixed);
	while(true) {
		cin >> i;
		if(start){
			large=i;
			small=i;
			start=false;
		}
		if(!cin.good())
			break; // avoid printing the last stuff
					// in the event of bad input
		cout << i;
		if(i>large) {
			cout << " The largest so far" << endl;
			large = i;
		}
/*		if(i<small) {
			cout << " The smallest so far" << endl;
			small = i;
		}*/
		
	}
	
	cout << "bye!" << endl;
	
    return 0;
}
