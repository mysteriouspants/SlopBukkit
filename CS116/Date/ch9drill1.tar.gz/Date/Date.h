/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090927, ch 9 drill #1
 */

struct Date {
	int y;
	int m;
	int d;
};

Date today;

void init_day(Date& dd, int y, int m, int d);
void add_day(Date& dd, int n);
