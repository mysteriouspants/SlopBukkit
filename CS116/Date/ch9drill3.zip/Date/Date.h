/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090927, ch 9 drill #1
 */

namespace fsdev {
	
	class Date {
	private:
		int y,m,d;
	public:
		Date(int _y, int _m, int _d);
		void add_day(int _n);
		int month() const { return m; };
		int year() const { return y; };
		int day() const { return d; };
	};

	Date today(2009,9,28);
	
}
