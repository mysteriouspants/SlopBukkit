/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090927, ch 9 drill #1
 */

#include "Date.h"

void init_day(Date& dd, int y, int m, int d) {
	if(y>=0&&m>0&&m<13&&d>0&&d<33) {
		dd.y=y;
		dd.m=m;
		dd.d=d;
	}
}
void add_day(Date& dd, int n) {
	dd.d+=n;
	if(dd.d>32) {
		int o=dd.d/32;
		dd.d-=32*o;
		dd.m+=o;
		if(dd.m>12) {
			o=dd.m/12;
			dd.m-=12*o;
			dd.y+=o;
		}
	}
}

