/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090927, ch 9 drill #1
 */

struct Date {
	int y,m,d;
	Date(int yy, int mm, int dd) {
		if(yy>=0&&mm>0&&mm<13&&dd>0&&dd<33) {
			y=yy;
			m=mm;
			d=dd;
		}
	}
	void add_day(int n) {
		d+=n;
		if(d>32) {
			int o=d/32;
			d-=32*o;
			m+=o;
			if(m>12) {
				o=m/12;
				m-=12*o;
				y+=o;
			}
		}
	}
};

Date today(2009,9,28);
