/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090927, ch 9 drill #1
 */

#include "Date.h"

namespace fsdev {
	Date::Date(int _y,
			   int _m,
			   int _d)
			   : y(_y),
			   m(_m),
			   d(_d) {
		
	}
	void Date::add_day(int _n) {
		d+=_n;
		if(d>32) {
			int o=d/32;
			d-=32*o;
			m+=o;
			if(m>12) {
				o=m/12;
				m-=12*o;
				y+=o;
			}
		}
	}
}

