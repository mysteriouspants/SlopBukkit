/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20091006, Chapter 10 Drill
 */

#include <iostream>

class Point {
private:
    double _x, _y;
public:
    Point(double x, double y)
	: _x(x), _y(y) {
        
    }
    double x() const { return _x; };
    double y() const { return _y; };
    void setX(double x) { _x = x; };
    void setY(double y) { _y = y; };
};

int main (int argc, char * const argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
