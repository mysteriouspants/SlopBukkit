/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20091006, Chapter 10 Drill
 */

#include <iostream>
#include <vector>

class Point {
private:
    double _x, _y;
public:
    Point(double x, double y)
	: _x(x), _y(y) {
        
    }
    double x() const { return _x; };
    double y() const { return _y; };
    void setX(double x) { _x = x; };
    void setY(double y) { _y = y; };
};

std::istream& operator >> (std::istream& is, Point& p) {
    double x, y;
    is >> x >> y;
    p.setX(x);
    p.setY(y);
    return is;
}

int main (int argc, char * const argv[]) {
	std::cout << "Enter seven x-y values" << std::endl;
    std::cout << "for example:" << std::endl;
    std::cout << "1: 12 11" << std::endl;
    std::vector<Point> originalPoints();
    Point p;
    for(size_t i=0; i<7; ++i) {
        std::cout << i+1 << ": ";
        std::cin >> p;
        originalPoints.push_back(p);
    }
}
