/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090918, Chapter 8 Drill
 */

#include "my.h"

int foo;

int main (int argc, char * const argv[]) {
	foo = 7;
	print_foo();
	print(99);
    return 0;
}
