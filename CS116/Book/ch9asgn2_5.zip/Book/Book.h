/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090926, pg 334 # 5
 */

#include <string>

namespace fsdev {
	
	typedef struct {
		size_t field1;
		size_t field2;
		size_t field3;
		wchar_t field4;
	} ISBN;
	
	typedef enum {
		YES,
		NO
	} shelf_status;
	
	class Book {
	private:
		ISBN _isbn;
		std::string _title;
		std::string _author;
		size_t _year;
		shelf_status _onShelf;
	public:
		Book();
		Book(
			 ISBN isbn,
			 std::string title,
			 std::string author,
			 size_t year,
			 shelf_status onShelf
			 );
		
		ISBN isbn() { return _isbn; };
		std::string title() { return _title; };
		std::string author() { return _author; };
		size_t year() { return _year; };
		shelf_status onShelf() { return _onShelf; };
		
		void setIsbn(ISBN isbn);
		void setTitle(std::string title);
		void setAuthor(std::string author);
		void setYear(size_t year);
		void setOnShelf(shelf_status onShelf);
	};
	
}