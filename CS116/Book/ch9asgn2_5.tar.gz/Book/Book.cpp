/*! Chris Miller (cmiller@fsdev.net), CS116
 *! Copyright (C) 2009 FSDEV.  Aw richts pitten by.
 *! Academic endorsement.  This code is not licensed for commercial use.
 *! 20090926, pg 334 # 5
 */

#include "Book.h"

fsdev::Book::Book() {
	
}

fsdev::Book::Book(
				  ISBN isbn,
				  std::string title,
				  std::string author,
				  size_t year,
				  shelf_status onShelf
				  ) : _isbn(isbn), _title(title), _author(author), _year(year), _onShelf(onShelf) {
	
}

void fsdev::Book::setIsbn(ISBN isbn) {
	_isbn = isbn;
}
void fsdev::Book::setTitle(std::string title) {
	_title = title;
}
void fsdev::Book::setAuthor(std::string author) {
	_author = author;
}
void fsdev::Book::setYear(size_t year) {
	_year = year;
}
void fsdev::Book::setOnShelf(shelf_status onShelf) {
	_onShelf = onShelf;
}
